#! /bin/sh
service tvheadend restart
exit 0