Just run the script from Kodi.

Enjoy ....

Please send Comments and Bugreports to hellyrulez@home.nl

