Helly Repo

Download latest zip from github.
Install from zipfile in kodi.

Please send Comments and Bugreports to hellyrulez@home.nl

