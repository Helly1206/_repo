Installation Notes for WebGrab++ Manager:
     
1. Install this Addon from repo, ZIP or if this fails copy the unpacked package
   to /home/kodi/.kodi/addons 
2. Install WebGrab++ in your operating system according to its installation instruction and
   set it up accordingly:
   http://www.webgrabplus.com/documentation

3. You can use resources/scripts/update.sh as script to start from the manager (when runnnig linux, on windows you need to make a similar script)
Copy the script to your wg++ location, change the working directory in the script, make iit execuable (chmod 755 update.sh) and refer to it from the settings

4. When using the python script, make sure wx-python is installed and allow remote access from this computer in kodi.

5. Enjoy!

Please send Comments and Bugreports to hellyrulez@home.nl

