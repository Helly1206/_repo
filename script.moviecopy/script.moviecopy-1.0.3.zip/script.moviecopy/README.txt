Installation Notes for MovieCopy:

     
1. Install this Addon from ZIP or if this fails copy the unpacked package
   to ~/.kodi/addons

2. Enjoy!

When running from OS:
1. Make sure kodi is running

2. Make sure 'zenity' is installed
   For debian/ ubuntu: sudo apt-get install zenity
   For windows: see http://placella.com/software/zenity/
   For other distro's: see http://ftp.gnome.org/pub/gnome/sources/zenity/

3. make a link to ~/.kodi/addons/script.moviecopy/resources/moviecopy or
   use the desktop file in the same folder to make a desktop entry (linux only)
   When using the desktop file, change the path accordingly.

4. Enjoy!

Please send Comments and Bugreports to hellyrulez@home.nl
