Installation Notes for Stream Generator:

     
1. Install this Addon from ZIP or if this fails copy the unpacked package
   to ~/.kodi/addons

2. Enjoy!

Please send Comments and Bugreports to hellyrulez@home.nl
